package OSS;
import java.util.LinkedList;
import java.util.Queue;
public class Process {
	String name;
    int burstTime;
    public Process(String name, int burstTime) {
        this.name = name;
        this.burstTime = burstTime;
}
  //public static void main(String[]args) {
	  //Process p1 = new Process("P1", 8);
      //Process p2 = new Process("P2", 6);
      //Process p3 = new Process("P3", 10);
      //Process p4 = new Process("P4", 4);
      //int quantum = 2;
      
      //Queue<Process> processQueue = new LinkedList<>();
      //processQueue.add(p1);
      //processQueue.add(p2);
      //processQueue.add(p3);
      //processQueue.add(p4);
      //RoundRobin(processQueue, quantum);
  //}
  public static void RoundRobin(Queue<Process> processQueue, int quantum) {
      while (!processQueue.isEmpty()) {
          Process currentProcess = processQueue.poll();

          System.out.println("Executing process " + currentProcess.name);

          if (currentProcess.burstTime > quantum) {
              
              currentProcess.burstTime -= quantum;
              System.out.println("Remaining burst time for " + currentProcess.name + ": " + currentProcess.burstTime);
              processQueue.add(currentProcess); 
          } else {
              
              System.out.println("Process " + currentProcess.name + " has completed.");
          }
      }
    
}
}
