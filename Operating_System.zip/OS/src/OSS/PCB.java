package OSS;

import java.util.Arrays;
import java.util.Comparator;

public class PCB {
    int processId;
    int arrivalTime;
    int burstTime;

    public PCB(int processId, int arrivalTime, int burstTime) {
        this.processId = processId;
        this.arrivalTime = arrivalTime;
        this.burstTime = burstTime;
    }
}
