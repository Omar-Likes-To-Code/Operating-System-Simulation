package OSS;

import java.util.ArrayList;
import java.util.List;
import java.util.PriorityQueue;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Collections;


class SJF {
 

   //public static void main(String[] args) {

        //List<PCB> processes = new ArrayList<>();
        //processes.add(new PCB(1, 0, 6));
        //processes.add(new PCB(2, 0, 8));
        //processes.add(new PCB(3, 0, 7));
        //processes.add(new PCB(4, 0, 3));



        //nonPreemptiveSJF(processes);
    //}

    public static void preemptiveSJF(List<PCB> processes) {
        System.out.println("Process Execution Order (SJF Preemptive):");

        PriorityQueue<PCB> priorityQueue = new PriorityQueue<>((p1, p2) -> p1.burstTime - p2.burstTime);

        int currentTime = 0;

        while (!processes.isEmpty() || !priorityQueue.isEmpty()) {

            while (!processes.isEmpty() && processes.get(0).arrivalTime <= currentTime) {
                priorityQueue.offer(processes.remove(0));
            }

           if (!priorityQueue.isEmpty()) {

              PCB currentProcess = priorityQueue.poll();

               System.out.println("Executing Process " + currentProcess.processId + " at time " + currentTime);

               currentProcess.burstTime--;

              if (currentProcess.burstTime == 0) {

                   System.out.println("Process " + currentProcess.processId + " completed");

                } else {

                    priorityQueue.offer(currentProcess);
                }
                currentTime++;
            } else {
                currentTime++;
            }
        }
    }

public static void nonPreemptiveSJF(List<PCB> processes) {
        System.out.println("Process Execution Order (SJF Non-Preemptive):");


        Collections.sort(processes, Comparator.comparingInt(p -> p.burstTime));

        int currentTime = 0;

        for (PCB process : processes) {

            if (process.arrivalTime > currentTime) {
                currentTime = process.arrivalTime;
            }

            System.out.println("Executing Process " + process.processId + " at time " + currentTime);


            currentTime += process.burstTime;

            System.out.println("Process " + process.processId + " completed");
            System.out.println("------------------------");

    }
    }}
