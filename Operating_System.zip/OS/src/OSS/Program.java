package OSS;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;

public class Program {
int id;
int a;
int b;
public Program(String filepath){
      try {
            File file = new File(filepath);
            Scanner scanner = new Scanner(file);
            while (scanner.hasNext()) {
                if (scanner.hasNextInt()) {
                    this.a = scanner.nextInt();
                    System.out.println("Read number: " + a);
                     this.b = scanner.nextInt();
                    System.out.println("Read number: " + b);
                } else {
                    scanner.next();
                    
                }
            }
            id++;

            scanner.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
      
    }

public void add () {
int z=this.a+this.b;
System.out.println(z);
}

public void sub () {
int p=this.a-this.b;
System.out.println(p);
}

public  void Div() {
int y=this.a/this.b;
System.out.println(y);
}

public  void mul () {
int x=this.a*this.b;
System.out.println(x);
}

public static void writefile(String filepath,int a,int b) {
	

    try {
        
        File file = new File(filepath);

        
        if (file.createNewFile()) {
            System.out.println("File created: " + file.getName());
        } else {
            System.out.println("File already exists.");
        }

        
        FileOutputStream fos = new FileOutputStream(file);
        String s = "a = ";
        s+= Integer.toString(a);
        s+= " ";
        fos.write(s.getBytes());
        String ss = "b = ";
        ss+= Integer.toString(b);
        fos.write(ss.getBytes());
        fos.close();
        

        System.out.println("Data written to the file.");

    } catch (IOException e) {
        System.out.println("An error occurred.");
        e.printStackTrace();
    }
    
    
    
    
	
}
public static  void rep (String filepath ) {
	try {
        File file = new File(filepath);
        Scanner scanner = new Scanner(file);
        while (scanner.hasNext()) {
            if (scanner.hasNextInt()) {
                int b  = scanner.nextInt();
                System.out.println(b);
               return;
            } else {
                scanner.next();
            }
        }

        scanner.close();
    } catch (FileNotFoundException e) {
        e.printStackTrace();
    }            
	
}






















}