package OSS;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

import OSS.Program;

import java.util.LinkedList;
import java.util.Queue;

public class OperatingSystem {
	
	 
	    public static void main (String[] args){
	        //Program p = new Program("C:\\Users\\belad\\OneDrive\\Desktop\\pp.txt");
            Program.rep("C:\\Users\\belad\\OneDrive\\Desktop\\pp2.txt");    
	        //System.out.println(p.a);
	        //System.out.println(p.b);
	      
	    }
	}

